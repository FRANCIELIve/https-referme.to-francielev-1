package au.com.shiftyjelly.pocketcasts.discover.view

class LoadingItem()
